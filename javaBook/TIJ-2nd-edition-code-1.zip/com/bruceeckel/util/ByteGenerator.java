//: com:bruceeckel:util:ByteGenerator.java
// From 'Thinking in Java, 2nd ed.' by Bruce Eckel
// www.BruceEckel.com. See copyright notice in CopyRight.txt.
package com.bruceeckel.util;
public interface ByteGenerator {
  byte next();
} ///:~