//: c05:Pie.java
// From 'Thinking in Java, 2nd ed.' by Bruce Eckel
// www.BruceEckel.com. See copyright notice in CopyRight.txt.
// The other class.

class Pie {
  void f() { System.out.println("Pie.f()"); }
} ///:~